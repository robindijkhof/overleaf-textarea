'use strict';

addDomainPermissionToggle();
